export type Project = {
    Title: string;
    Description: string;
    "Image Source": string;
  }